create function interval_pl_timestamptz(interval, timestamp with time zone) returns timestamp with time zone
STABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
