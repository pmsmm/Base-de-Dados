create function check_categoria_type() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF nome FROM CategoriaSimples WHERE (NEW.nome = CategoriaSimples.nome) IS NOT NULL THEN
			RAISE EXCEPTION 'Uma categoria nao pode ser super e simples ao mesmo tempo!';
		END IF;
		IF nome FROM SuperCategoria WHERE (NEW.nome = SuperCategoria.nome) IS NOT NULL THEN
			RAISE EXCEPTION 'Uma categoria nao pode ser super e simples ao mesmo tempo!';
		END IF;

		RETURN NEW;
	END;
$$;
