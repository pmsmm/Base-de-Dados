create function date_verify() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF instante FROM evento_reposicao WHERE (NEW.instante::date <= evento_reposicao.instante::date) IS NOT NULL THEN
			RAISE EXCEPTION 'O evento de reposicao que esta a tentar inserir e inferior ao evento de reposicao anterior o que e impossivel!';
		END IF;

		RETURN NEW;
	END;
$$;
