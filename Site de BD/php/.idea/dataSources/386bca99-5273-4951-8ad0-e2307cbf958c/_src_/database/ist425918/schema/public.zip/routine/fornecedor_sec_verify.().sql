create function fornecedor_sec_verify() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF NEW.nif IS NULL THEN
			RAISE EXCEPTION '% Nao pode ser NULL', NEW.nif;
		END IF;
		IF NEW.ean IS NULL THEN
			RAISE EXCEPTION '% Nao pode ser NULL', NEW.ean;
		END IF;
		IF COUNT(nif) FROM produto WHERE (NEW.nif = produto.nif) AND (NEW.ean = produto.ean) IS NOT NULL THEN
			RAISE EXCEPTION 'Um fornecedor nao pode ser primario e secundario para o mesmo produto';
		END IF;

		NEW.nif := current_nif;
		NEW.ean := current_ean;
		RETURN NEW;
	END;
$$;
