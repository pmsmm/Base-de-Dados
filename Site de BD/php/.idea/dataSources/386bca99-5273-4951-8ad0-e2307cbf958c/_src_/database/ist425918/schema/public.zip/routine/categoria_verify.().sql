create function categoria_verify() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		IF NEW.snome = NEW.cnome THEN
			RAISE EXCEPTION 'Uma SuperCategoria nao pode ser constituida por si propria';
		END IF;
		IF COUNT(*) FROM CategoriaSimples, SuperCategoria WHERE (NEW.snome = CategoriaSimples.nome) IS NOT NULL THEN
			RAISE EXCEPTION 'A SuperCategoria que esta a tentar adicionar e uma CategoriaSimples!';
		END IF;
		IF COUNT(*) FROM constituida WHERE (NEW.snome = constituida.cnome) AND (NEW.cnome = constituida.snome) IS NOT NULL THEN
			RAISE EXCEPTION 'Nao sao permitidos ciclos de categorias!';
		END IF;

		RETURN NEW;
	END;
$$;
